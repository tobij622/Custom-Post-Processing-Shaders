using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;
using System;

[Serializable, VolumeComponentMenu("Post-processing/Custom/pixelShader")]
public sealed class pixelShader : CustomPostProcessVolumeComponent, IPostProcessComponent
{
    [Tooltip("Controls the scale of the effect.")]
    public ClampedFloatParameter scale = new ClampedFloatParameter(100f, 1f, 100f);

    [Tooltip("X dimension of resolution.")]
    public FloatParameter xDimension = new FloatParameter(16.0f);

    [Tooltip("Y dimension of resolution.")]
    public FloatParameter yDimension = new FloatParameter(9.0f);

    Material m_Material;

    public bool IsActive() => m_Material != null && scale.value > 0f;

    // Do not forget to add this post process in the Custom Post Process Orders list (Project Settings > HDRP Default Settings).
    public override CustomPostProcessInjectionPoint injectionPoint => CustomPostProcessInjectionPoint.AfterPostProcess;

    const string kShaderName = "Hidden/Shader/pixelShader";

    public override void Setup()
    {
        if (Shader.Find(kShaderName) != null)
            m_Material = new Material(Shader.Find(kShaderName));
        else
            Debug.LogError($"Unable to find shader '{kShaderName}'. Post Process Volume pixelShader is unable to load.");
    }

    public override void Render(CommandBuffer cmd, HDCamera camera, RTHandle source, RTHandle destination)
    {
        if (m_Material == null)
            return;

        m_Material.SetFloat("_Scale", scale.value);
        m_Material.SetFloat("_xDimension", xDimension.value);
        m_Material.SetFloat("_yDimension", yDimension.value);
        m_Material.SetTexture("_InputTexture", source);
        HDUtils.DrawFullScreen(cmd, m_Material, destination);
    }

    public override void Cleanup()
    {
        CoreUtils.Destroy(m_Material);
    }
}
